"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const tslib_1 = require("tslib");
const client_s3_1 = require("@aws-sdk/client-s3");
const sharp_1 = tslib_1.__importDefault(require("sharp"));
const stream_1 = require("stream");
const DESKTOP_MAX_WIDTH = 1500;
const DESKTOP_PANORAMA_MAX_WIDTH = 2500;
const DESKTOP_MAX_HEIGHT = 1200;
const DESKTOP_MAX_SQUARE = 900;
const s3Client = new client_s3_1.S3Client();
const streamToString = (stream) => {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on("data", (chunk) => chunks.push(chunk));
        stream.on("error", reject);
        stream.on("end", () => resolve(Buffer.concat(chunks)));
    });
};
const handler = async (event, context) => {
    console.log("Starting image processing with event...", JSON.stringify(event));
    if (event.Records.length > 1)
        throw new Error("Not supported. Multiple records present in S3 event");
    const key = event.Records[0].s3.object.key;
    const newKey = `${key.split('/')[0]}/${key.split('/')[1]}/${crypto.randomUUID()}.jpeg`;
    console.log('New key: ', newKey);
    let getObjectResponse;
    getObjectResponse = await s3Client.send(new client_s3_1.GetObjectCommand({
        Bucket: process.env.DUMP_BUCKET_NAME,
        Key: key,
    }));
    let stream = getObjectResponse.Body;
    let content_buffer;
    if (stream instanceof stream_1.Readable) {
        content_buffer = Buffer.concat(await stream.toArray());
    }
    else {
        throw new Error('Unknown object stream type');
    }
    console.log('doing buffer...');
    var output_buffer = await (0, sharp_1.default)(content_buffer).resize(200).toBuffer();
    console.log('buffer done');
    console.log("Retrieved image to process: ", key);
    // SHARP PROCESSING
    console.log("converted image to stream...");
    let image = (0, sharp_1.default)(content_buffer, {
        failOn: "none",
    });
    console.log("called sharp()...");
    let metadata = await image.metadata();
    let imgWidth = metadata.width;
    let imgHeight = metadata.height;
    /**
     * Sharp does something weird in that portrait photos are read as landscape
     * So the width is actually the height and vice versa
     *
     * The orientation flag tells the position of the camera when the photo was taken
     *
     * The values 5,6,7,8 are all the positions where the camera is upright
     */
    if (metadata.orientation && [5, 6, 7, 8].includes(metadata.orientation)) {
        imgWidth = metadata.height;
        imgHeight = metadata.width;
    }
    let imageType;
    if (!imgWidth || !imgHeight) {
        throw new Error(`Image dimensions are not defined. Width: ${imgWidth}, Height: ${imgHeight}`);
    }
    if (imgWidth / imgHeight > 2) {
        imageType = "panorama";
    }
    else if (imgWidth > imgHeight) {
        imageType = "landscape";
    }
    else if (imgWidth < imgHeight) {
        imageType = "portrait";
    }
    else {
        imageType = "square";
    }
    let resizeTo = {};
    switch (imageType) {
        case "landscape":
            if (imgWidth > DESKTOP_MAX_WIDTH)
                resizeTo = { width: DESKTOP_MAX_WIDTH };
            else
                resizeTo = { width: metadata.width };
            break;
        case "portrait":
            if (imgHeight > DESKTOP_MAX_HEIGHT)
                resizeTo = { width: DESKTOP_MAX_HEIGHT };
            else
                resizeTo = { height: metadata.height };
            break;
        case "panorama":
            resizeTo = { width: DESKTOP_PANORAMA_MAX_WIDTH };
            break;
        case "square":
            resizeTo = { width: DESKTOP_MAX_SQUARE, height: DESKTOP_MAX_SQUARE };
            break;
        default:
            break;
    }
    const processedImage = await image
        .resize(resizeTo)
        .withMetadata()
        .jpeg({ quality: 60 })
        .toColorspace("srgb")
        .toBuffer();
    console.log('resized imaged');
    // SAVE TO OPTIMIZED BUCKET
    const saveProcessedImageInput = {
        Body: processedImage,
        Bucket: process.env.OPTIMIZED_BUCKET_NAME,
        Key: key,
    };
    const saveProcessedImageCommand = new client_s3_1.PutObjectCommand(saveProcessedImageInput);
    await s3Client.send(saveProcessedImageCommand);
    return {
        body: { key },
        statusCode: 200,
    };
};
exports.handler = handler;
//# sourceMappingURL=index.js.map